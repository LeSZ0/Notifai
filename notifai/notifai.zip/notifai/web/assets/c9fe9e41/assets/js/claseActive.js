function claseActive(id){
	$('.activar').removeClass('active');
	$('#' + id ).addClass('active');
}