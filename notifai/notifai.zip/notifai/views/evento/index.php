<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\EventoSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Todos los eventos');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="evento-index">

    <h1 class='page-head-line'><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Nuevo evento'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id_evento',
            'nombre',
            'descripcion',
            'fecha_inicio',
            'fecha_fin',
            'id_estado',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
