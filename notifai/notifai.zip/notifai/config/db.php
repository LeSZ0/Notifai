<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=notifai',
    'username' => 'root',
    'password' => 'ujqr87cet',
    'charset' => 'utf8',
];
